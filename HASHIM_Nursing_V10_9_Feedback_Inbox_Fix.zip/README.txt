HASHIM Nursing offline-first web + Android project

Brand: HASHIM Nursing | Learn. Practice. Lead.
Themes: Complete Black, Lavender + Dark Charcoal, Ocean Glow.
Navigation: separate sections, bottom/section navigation and horizontal swipe gestures on mobile.
Data: local device storage; no AI and no cloud sync.

Android APK is built by GitHub Actions from .github/workflows/build-apk.yml. Upload this project to a GitHub repository and run the workflow. The ZIP is a source project, not a compiled APK.

UPDATED PROJECT NOTES
- Added source-derived General Awareness questions from the supplied RRB General Knowledge PDF.
- Added source-derived Mathematics & General Arithmetic questions with options, answers and worked explanations from the supplied arithmetic PDF.
- Preserved existing nursing notes and local progress features.
- Android-only: added a home-screen quick flashcard widget and a daily reminder notification (around 7 PM, subject to Android scheduling/notification permission).
- Widget cards are currently a small built-in nursing set and do not yet sync to the full notes library. Notifications are local reminders, not remote push notifications.
- Rebuild the Android APK from android-app/ using Android Studio (JDK 17). This ZIP is source code; an APK was not built or tested in this environment.
- Note: The mathematics PDF cover says 520 MCQs, while the extraction detected 600 question blocks; review the imported mathematics section against the PDF before relying on the count.


Flashcard widget connection: The Android widget is now backed by the full app notes dataset (android-app/app/src/main/assets/flashcards.json), rather than the six hard-coded demo cards. The dataset includes all non-empty note entries exported from RAILPREP_NOTES. Rebuild and reinstall the app to apply the code change.


RRB SOURCE MATERIAL INCLUDED
- RRB Nursing Superintendent Mathematics & General Arithmetic PDF: labeled question blocks extracted with options, correct answers and worked calculations. The PDF cover says 520 MCQs; 600 labeled question blocks with answer/calculation text were detected and retained from the actual document. Verify source PDF for its intended question count.
- RRB General Knowledge PDF: 500 MCQs extracted with options and answers.
- Original PDFs are included in resources/source-pdfs/.


VERSION 10 – 30-DAY CHALLENGE
- Added a dedicated 30-Day Nursing Officer Challenge section, separate from Notes Library, Quick Review, Flashcards, Practice MCQs and Mock Tests.
- Days 1–28 allocate the available note entries across the matching subject categories; Day 29 is full nursing revision; Day 30 is a mock-test and final-review day.
- Challenge start date and completed days are saved locally in a separate storage key. Resetting the challenge does not clear bookmarks or other study progress.
- Website and Android WebView assets are synchronized. Rebuild/reinstall the Android app or refresh the website to apply the update.
- The day plan is a study schedule based on the supplied content categories, not an official exam syllabus.

V10.4 Learning Tools: Open the new “My Learning” section for Daily Study Goals, XP & Levels, Mistake Notebook, Weak Topic Analysis and Performance Dashboard. The tools are device-local and work offline. Weak-topic status is calculated from revision coverage, not mock-test accuracy. Set your daily target in My Learning Centre.


VERSION 10.6 — PRIVATE FEEDBACK CHAT
See FEEDBACK_REPLY_SETUP.txt for Firebase setup. Students and the verified owner can exchange multiple private messages within each feedback item. Publish FIRESTORE_FEEDBACK_RULES.txt before testing.
