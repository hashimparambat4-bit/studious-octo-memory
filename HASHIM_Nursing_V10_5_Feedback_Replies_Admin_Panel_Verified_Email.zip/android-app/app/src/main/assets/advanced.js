/* RailPrep Complete — offline study engines */
(()=>{'use strict';
const NOTES=window.RAILPREP_NOTES||[], SUBJECTS=window.RAILPREP_SUBJECTS||[], $=id=>document.getElementById(id);
const STORE='railprep_complete_v1';let extra={quizHistory:[],due:{},dailyTarget:15,dark:true};
try{extra={...extra,...JSON.parse(localStorage.getItem(STORE)||'{}')}}catch(e){}
const hadLegacyAI=('apiKey' in extra)||('model' in extra); delete extra.apiKey; delete extra.model; // remove any legacy AI credentials/settings
if(hadLegacyAI){try{localStorage.setItem(STORE,JSON.stringify(extra))}catch(e){}}
let bank=[],quiz=[],qi=0,answers=[],started=0,timer=null,seconds=0,quizMode='practice',chat=[];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function save(){try{localStorage.setItem(STORE,JSON.stringify(extra))}catch(e){notice('Could not save locally. Export a backup or free device storage.')}}
function notice(s){let t=$('toast');if(t){t.textContent=s;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)}}
function parseBank(){
 const seen=new Set();
 for(const n of NOTES){
   const raw=String(n.text||'').trim();
   // Source-PDF MCQs already contain their own A-D options and answer. Keep them intact; never generate distractors for them.
   const lines=raw.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
   const answerLine=lines.find(x=>/^Answer\s*:/i.test(x));
   const optionLines=lines.filter(x=>/^[A-D][.)]\s*/i.test(x));
   if(answerLine && optionLines.length>=4){
     const qline=lines.find(x=>!(/^[A-D][.)]\s*/i.test(x)) && !/^Answer\s*:/i.test(x) && /\?\s*$/.test(x));
     const q=qline||lines.find(x=>!(/^[A-D][.)]\s*/i.test(x)) && !/^Answer\s*:/i.test(x));
     const match=answerLine.match(/^Answer\s*:\s*([A-D])(?:[.)])?\s*(.*)$/i);
     const options=optionLines.slice(0,4).map(line=>{const m=line.match(/^([A-D])[.)]\s*(.*)$/i);return m?{letter:m[1].toUpperCase(),text:m[2].trim()}:null}).filter(Boolean);
     if(q && match && options.length===4 && options.some(o=>o.letter===match[1].toUpperCase())){
       const correctLetter=match[1].toUpperCase();
       const norm=q.toLowerCase()+'|'+options.map(o=>o.text.toLowerCase()).join('|');
       if(!seen.has(norm)){seen.add(norm);bank.push({id:n.id,number:n.number,subject:n.subject,q:q.replace(/^\d+[.)]\s*/,''),a:options.find(o=>o.letter===correctLetter).text,source:raw,explicit:true,options:options.map(o=>({text:o.text,correct:o.letter===correctLetter}))});}
       continue;
     }
   }
   // Legacy short question/answer notes, handled conservatively.
   let i=raw.lastIndexOf('?');if(i<8||i>=raw.length-2)continue;
   let q=raw.slice(0,i+1).trim(),ans=raw.slice(i+1).trim();
   ans=ans.replace(/\s*\((?:AIIMS|NORCET|RRB|PGI|PGIMER|ESIC|DSSSB|JIPMER|GMCH|SGPGI|KPSC|UPUMS|CHO|NCL|SCTIMST|VSSC|NIA|HPSSC|ODISHA|BMHR|Bihar|WCL|Nursing Officer|FAQs)[^)]*\)\s*$/i,'').replace(/^[-–—: ]+/,'').trim();
   if(q.length<10||!ans||ans.length>180||/[?]$/.test(ans)||/^which of the following/i.test(ans))continue;
   if(/^([A-D][.)]\s)/i.test(ans)||/\bAnswer\s*:/i.test(ans))continue;
   const norm=(q+'|'+ans).toLowerCase();if(seen.has(norm))continue;seen.add(norm);
   bank.push({id:n.id,number:n.number,subject:n.subject,q,a:ans,source:raw});
 }
}
parseBank();
function getSubject(){return (quizMode==='mock'?$('mockSubject')?.value:$('quizSubject')?.value)||'All subjects'}
function answerKind(item){
 const q=String(item.q||'').toLowerCase(), a=String(item.a||'').trim();
 // Prefer what the question is asking, not a superficial pattern in the answer.
 if(/\b(year|which year|when was|in what year|date of|year of)\b/.test(q))return 'year';
 if(/\b(who|whose|father of|mother of|known as|named after|who discovered|who invented|who introduced|who developed|who founded|who wrote|which nurse)\b/.test(q))return 'person';
 if(/\b(where|which city|which state|which country|located in|place of)\b/.test(q))return 'place';
 if(/\b(disinfected? with|disinfectant|sterili[sz]ed with|washed with .* disinfect|thermometer.*soap|antiseptic solution)\b/.test(q))return 'disinfectant';
 if(/\b(causative agent|caused by|organism responsible|which organism|pathogen)\b/.test(q))return 'organism';
 if(/\b(drug of choice|antidote|which drug|medication used|drug used|treatment of choice)\b/.test(q))return 'drug';
 if(/\b(normal value|normal range|how many|how much|dose|dosage|temperature|pulse rate|respiratory rate|blood pressure|how long|duration|weight|height|volume|quantity|number of|percentage|percent)\b/.test(q))return /\b(percent|percentage)\b/.test(q)?'percent':'numeric';
 if(/\b(diaphragm is|is a\/an|is an example of|classified as|type of muscle|which muscle|what type of)\b/.test(q)){
   if(/\bmuscle\b/i.test(a))return 'muscle-type';
   if(/\b(bone|nerve|artery|vein|organ|gland|tissue)\b/i.test(a))return 'anatomy-class';
 }
 if(/\b(muscle|diaphragm|nerve|bone|artery|vein|organ|gland|anatomy|anatomical|tissue)\b/.test(q))return 'anatomy-class';
 if(/\b(disease|disorder|syndrome|infection)\b/.test(q))return 'disease';
 if(/\b(instrument|device|equipment|apparatus)\b/.test(q))return 'instrument';
 if(/\b(vitamin)\b/.test(q))return 'vitamin';
 if(/\b(hormone)\b/.test(q))return 'hormone';
 if(/\b(act|law|legislation|year of enactment)\b/.test(q))return 'law';
 // Conservative fallback: only use tightly typed facts, never arbitrary phrases.
 if(/\b(18|19|20)\d{2}\b/.test(a))return 'year';
 if(/^\d+(?:\.\d+)?\s*(?:mg|mcg|g|kg|ml|l|mmhg|cm|mm|hours?|days?|weeks?|months?|years?|°c|°f|meq\/l)?$/i.test(a))return 'numeric';
 if(/\b(savlon|detol|dettol|chlorhexidine|alcohol|spirit|iodine|povidone|antiseptic|disinfectant)\b/i.test(a))return 'disinfectant';
 if(/\b(skeletal muscle|smooth muscle|cardiac muscle|voluntary muscle|involuntary muscle)\b/i.test(a))return 'muscle-type';
 if(/\b(bacteria|bacterium|virus|fungus|parasite|staphylococcus|streptococcus|mycobacterium|escherichia)\b/i.test(a))return 'organism';
 if(/\b(tablet|injection|antibiotic|insulin|heparin|atropine|adrenaline|epinephrine|paracetamol|drug)\b/i.test(a))return 'drug';
 if(/^[A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,4}$/.test(a))return 'proper-name';
 return 'unclassified';
}
function compatibleAnswers(item){
 const kind=answerKind(item), norm=item.a.toLowerCase().trim();
 if(kind==='unclassified')return [];
 return bank.filter(x=>{
   if(x.id===item.id||x.a.toLowerCase().trim()===norm||x.a.length>100)return false;
   if(answerKind(x)!==kind)return false;
   // Keep the option set in the same subject unless the fact type is inherently cross-subject.
   if(x.subject!==item.subject && !['year','numeric','percent','muscle-type','disinfectant'].includes(kind))return false;
   // Avoid visibly different answer shapes (e.g. a full sentence among short terms).
   const words=t=>t.trim().split(/\s+/).length;
   if(Math.abs(words(x.a)-words(item.a))>2)return false;
   if(kind==='year'&&!/^\s*(18|19|20)\d{2}\s*$/.test(x.a))return false;
   if(kind==='numeric'&&!/^\s*\d+(?:[.,]\d+)?\s*(?:mg|mcg|g|kg|ml|l|mmhg|cm|mm|hours?|days?|weeks?|months?|years?|°c|°f|meq\/l)?\s*$/i.test(x.a))return false;
   if(kind==='muscle-type'&&!/\b(skeletal muscle|smooth muscle|cardiac muscle|voluntary muscle|involuntary muscle)\b/i.test(x.a))return false;
   if(kind==='disinfectant'&&!/\b(savlon|detol|dettol|chlorhexidine|alcohol|spirit|iodine|povidone|antiseptic|disinfectant)\b/i.test(x.a))return false;
   return true;
 });
}
function makeQuiz(count,mode){
 quizMode=mode;
 const selected=getSubject();
 let pool=bank.filter(x=>selected==='All subjects'||x.subject===selected);
 let statementMode=false;
 // Some source-PDF entries are facts rather than explicit Q&A. If there are too few
 // parsed Q&As, build clearly-labelled statement-recall items from notes in that subject.
 if(pool.length<4){
   const sourceNotes=NOTES.filter(n=>(selected==='All subjects'||n.subject===selected)&&String(n.text||'').trim().length>20);
   if(sourceNotes.length<4){notice('Not enough source entries for this subject. Try All subjects.');return}
   statementMode=true;
   pool=sourceNotes.map(n=>({id:n.id,number:n.number,subject:n.subject,q:`Which statement is taken from the ${n.subject} study notes?`,a:String(n.text).trim(),source:String(n.text).trim(),_statement:true}));
 }
 pool=pool.slice().sort(()=>Math.random()-.5);
 quiz=[];
 for(const item of pool){
   if(item.explicit && Array.isArray(item.options) && item.options.length===4){ quiz.push({...item,options:item.options.map(o=>({...o}))}); if(quiz.length>=count)break; continue; }
   let distractors=statementMode
     ? pool.filter(x=>x.id!==item.id&&x.subject===item.subject)
     : compatibleAnswers(item);
   distractors=distractors.sort(()=>Math.random()-.5);
   const opts=[{text:item.a,correct:true}],used=new Set([item.a.toLowerCase().trim()]);
   for(const d of distractors){const k=d.a.toLowerCase().trim();if(!used.has(k)){used.add(k);opts.push({text:d.a,correct:false});if(opts.length===4)break}}
   if(opts.length===4)quiz.push({...item,options:opts.sort(()=>Math.random()-.5)});
   if(quiz.length>=count)break;
 }
 if(!quiz.length&&!statementMode){
   const sourceNotes=NOTES.filter(n=>(selected==='All subjects'||n.subject===selected)&&String(n.text||'').trim().length>20);
   const fallback=sourceNotes.map(n=>({id:n.id,number:n.number,subject:n.subject,q:`Which statement is taken from the ${n.subject} study notes?`,a:String(n.text).trim(),source:String(n.text).trim(),_statement:true}));
   for(const item of fallback.slice().sort(()=>Math.random()-.5)){
     const opts=[{text:item.a,correct:true}],used=new Set([item.a.toLowerCase().trim()]);
     for(const d of fallback.filter(x=>x.id!==item.id&&x.subject===item.subject).sort(()=>Math.random()-.5)){const k=d.a.toLowerCase().trim();if(!used.has(k)){used.add(k);opts.push({text:d.a,correct:false});if(opts.length===4)break}}
     if(opts.length===4)quiz.push({...item,options:opts.sort(()=>Math.random()-.5)});
     if(quiz.length>=count)break;
   }
   statementMode=quiz.length>0;
 }
 if(!quiz.length){notice('Not enough distinct source entries for this subject. Try All subjects.');return}
 if(statementMode)notice('Recall quiz: questions are generated from source-note statements, not original MCQs.');
 if(statementMode)notice('Recall quiz: questions are generated from source-note statements, not original MCQs.');
 else if(quiz.length<count)notice(`Built ${quiz.length} questions; some entries lacked three compatible options.`);
 qi=0;answers=Array(quiz.length).fill(null);quizMode=mode;started=Date.now();seconds=mode==='mock'?quiz.length*60:0;go('quiz');$('quizIntro').hidden=true;$('quizArea').hidden=false;$('quizResult').hidden=true;renderQ();updateTimer();if(timer)clearInterval(timer);if(mode==='mock')timer=setInterval(()=>{seconds--;updateTimer();if(seconds<=0)finishQuiz()},1000);else $('quizTimer').textContent='Practice mode';
}
function updateTimer(){if(!$('quizTimer'))return;let m=Math.floor(seconds/60),s=seconds%60;$('quizTimer').textContent=quizMode==='mock'?`⏱ ${m}:${String(s).padStart(2,'0')}`:'Practice mode · no timer'}
function renderQ(){if(!quiz[qi])return;let q=quiz[qi];$('qPosition').textContent=`QUESTION ${qi+1} OF ${quiz.length}`;$('quizHeading').textContent=quizMode==='mock'?'Timed mock test':'Practice session';$('qProgress').style.width=((qi+1)/quiz.length*100)+'%';$('qSubject').textContent=q.subject;$('qText').textContent=q.q;$('qOptions').innerHTML=q.options.map((o,i)=>`<button class="option ${answers[qi]===i?'selected':''}" data-opt="${i}"><span class="opt-letter">${'ABCD'[i]}</span><span>${esc(o.text)}</span></button>`).join('');$('qOptions').querySelectorAll('[data-opt]').forEach(b=>b.onclick=()=>{answers[qi]=+b.dataset.opt;renderQ();if(quizMode==='practice')showFeedback()});$('qFeedback').innerHTML='';if(answers[qi]!==null&&quizMode==='practice')showFeedback();$('qPrev').disabled=qi===0;$('qNext').textContent=qi===quiz.length-1?'Finish test':'Next question →';}
function showFeedback(){let q=quiz[qi],chosen=q.options[answers[qi]],correct=q.options.find(o=>o.correct);$('qFeedback').innerHTML=`<div class="feedback ${chosen?.correct?'good':'bad'}"><strong>${chosen?.correct?'Correct':'Not quite'}</strong><p>Answer: ${esc(correct.text)}</p><small>Source entry #${q.id}: ${esc(q.source)}</small></div>`}
function finishQuiz(){if(timer)clearInterval(timer);timer=null;let right=0,attempted=0;quiz.forEach((q,i)=>{if(answers[i]!==null){attempted++;if(q.options[answers[i]]?.correct)right++}});let subjectBreakdown={};quiz.forEach((q,i)=>{let k=q.subject;if(!subjectBreakdown[k])subjectBreakdown[k]={correct:0,total:0};subjectBreakdown[k].total++;if(answers[i]!==null&&q.options[answers[i]]?.correct)subjectBreakdown[k].correct++});let result={date:new Date().toISOString(),mode:quizMode,total:quiz.length,attempted,correct:right,subject:getSubject(),subjectBreakdown};extra.quizHistory.unshift(result);extra.quizHistory=extra.quizHistory.slice(0,200);let today=new Date().toISOString().slice(0,10);if(extra.dailyDate!==today){extra.dailyDate=today;extra.dailyCount=0}extra.dailyCount=(extra.dailyCount||0)+attempted;save();$('quizArea').hidden=true;$('quizResult').hidden=false;$('quizScore').textContent=`${right} / ${quiz.length}`;$('quizSummary').textContent=`${Math.round(right/quiz.length*100)}% correct · ${attempted} attempted · ${quizMode==='mock'?'Mock test':'Practice session'}`;$('quizReview').innerHTML=quiz.map((q,i)=>{let a=answers[i],ok=a!==null&&q.options[a]?.correct;return `<article class="note"><div class="note-top"><span class="note-id">${i+1}. ${ok?'✓ Correct':a===null?'— Not answered':'✕ Incorrect'}</span><span class="tag">${esc(q.subject)}</span></div><p class="note-text"><strong>${esc(q.q)}</strong></p><p class="hint">Correct answer: ${esc(q.options.find(o=>o.correct).text)}</p><p class="hint">Source entry #${q.id}: ${esc(q.source)}</p></article>`}).join('');updateHomeStats()}
function go(v){if(typeof window.railprepGo==='function')window.railprepGo(v);else{document.querySelectorAll('.view').forEach(x=>x.classList.toggle('active',x.id==='view-'+v));document.querySelectorAll('#mainNav [data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===v))}window.scrollTo({top:0,behavior:'smooth'})}
function updateHomeStats(){let h=extra.quizHistory,acc=h.reduce((s,x)=>s+x.correct,0),tot=h.reduce((s,x)=>s+x.total,0);if($('extraSessions'))$('extraSessions').textContent=h.length+' sessions';if($('extraAccuracy'))$('extraAccuracy').textContent=tot?Math.round(acc/tot*100)+'%':'—';if($('extraSessions2'))$('extraSessions2').textContent=h.length;if($('targetInput'))$('targetInput').value=extra.dailyTarget||15;if($('dueCount'))$('dueCount').textContent=NOTES.filter(n=>due(n.id)).length;let today=new Date().toISOString().slice(0,10),daily=extra.dailyDate===today?(extra.dailyCount||0):0,target=extra.dailyTarget||15;if($('dailyGoal'))$('dailyGoal').textContent=daily+' / '+target;if($('dailyFill'))$('dailyFill').style.width=Math.min(100,Math.round(daily/target*100))+'%';if($('dailyMessage'))$('dailyMessage').textContent=daily>=target?'Daily target reached — great work!':`${Math.max(0,target-daily)} more questions to reach today's target.`;if($('quizWeakAreas')){let by={};h.forEach(x=>{if(x.subjectBreakdown){Object.entries(x.subjectBreakdown).forEach(([k,v])=>{if(!by[k])by[k]={c:0,t:0,n:0};by[k].c+=v.correct;by[k].t+=v.total;by[k].n++})}else if(x.subject&&x.subject!=='All subjects'){if(!by[x.subject])by[x.subject]={c:0,t:0,n:0};by[x.subject].c+=x.correct;by[x.subject].t+=x.total;by[x.subject].n++}});let rows=Object.entries(by).map(([k,v])=>({k,p:Math.round(v.c/Math.max(1,v.t)*100),...v})).sort((a,b)=>a.p-b.p);$('quizWeakAreas').innerHTML=rows.length?rows.map(x=>`<div class="barrow"><span>${esc(x.k)}</span><div class="bar"><span style="width:${x.p}%"></span></div><span>${x.p}%</span></div>`).join(''):'<p class="hint">Complete a quiz to start building your subject performance report.</p>'}}
function due(id){let d=extra.due[id];return !d||d.next<=Date.now()}
function markSpaced(id,quality){let d=extra.due[id]||{interval:0,ease:2.5,reps:0};if(quality<3){d.reps=0;d.interval=1}else{d.reps++;d.interval=d.reps===1?1:d.reps===2?3:Math.round(d.interval*d.ease);d.ease=Math.max(1.3,d.ease+(0.1-(5-quality)*(0.08+(5-quality)*0.02)))}d.next=Date.now()+d.interval*86400000;extra.due[id]=d;save()}
function renderSpaced(){let dueNotes=NOTES.filter(n=>due(n.id)).slice(0,100);$('spacedList').innerHTML=dueNotes.length?dueNotes.map(n=>`<article class="note"><div class="note-top"><span class="note-id">ENTRY ${n.id}</span><span class="tag">${esc(n.subject)}</span></div><p class="note-text">${esc(n.text)}</p><div class="note-actions"><button class="mini" data-rate="1" data-id="${n.id}">Again · 1 day</button><button class="mini" data-rate="3" data-id="${n.id}">Hard · 3 days</button><button class="mini" data-rate="4" data-id="${n.id}">Good · schedule</button><button class="mini" data-rate="5" data-id="${n.id}">Easy · schedule</button></div></article>`).join(''):'<div class="panel empty">You are caught up! No notes are due right now.</div>'; $('spacedList').querySelectorAll('[data-rate]').forEach(b=>b.onclick=()=>{markSpaced(+b.dataset.id,+b.dataset.rate);renderSpaced();updateHomeStats();notice('Revision scheduled')})}
function buildUI(){const nav=$('mainNav');[['practice','▣','Practice MCQs'],['mock','◷','Mock tests'],['spaced','↻','Spaced revision'],['settings','⚙','Settings']].forEach(([v,ic,label])=>{let b=document.createElement('button');b.dataset.view=v;b.innerHTML=`<span class="navicon">${ic}</span>${label}`;nav.appendChild(b);b.onclick=()=>{if(v==='practice')setupQuiz('practice');else if(v==='mock')setupQuiz('mock');else if(v==='spaced')renderSpaced();else if(v==='settings')loadSettings();go(v)}});}
function setupQuiz(mode){quizMode=mode;go(mode==='mock'?'mock':'practice');if($('quizIntro'))$('quizIntro').hidden=false;if($('quizArea'))$('quizArea').hidden=true;if($('quizResult'))$('quizResult').hidden=true}
function loadSettings(){if($('targetInput'))$('targetInput').value=extra.dailyTarget||15;updateHomeStats()}
function attach(){buildUI();const opts=SUBJECTS.map(s=>`<option>${esc(s)}</option>`).join('');['quizSubject','mockSubject'].forEach(id=>{if($(id))$(id).innerHTML='<option>All subjects</option>'+opts});$('startPractice').onclick=()=>{let c=+$('practiceCount').value||15;makeQuiz(c,'practice')};$('startMock').onclick=()=>{let c=+$('mockCount').value||50;makeQuiz(c,'mock')};$('qPrev').onclick=()=>{if(qi>0){qi--;renderQ()}};$('qNext').onclick=()=>{if(qi<quiz.length-1){qi++;renderQ()}else finishQuiz()};$('quitQuiz').onclick=()=>{if(confirm('End this session? Your answers will be scored.'))finishQuiz()};$('retryQuiz').onclick=()=>setupQuiz(quizMode);$('targetSave').onclick=()=>{extra.dailyTarget=Math.max(5,Math.min(200,+$('targetInput').value||15));save();updateHomeStats();notice('Daily target saved')};$('clearQuizHistory').onclick=()=>{if(confirm('Clear local quiz history?')){extra.quizHistory=[];save();updateHomeStats();notice('Quiz history cleared')}};$('exportFull').onclick=()=>{let base={app:'RailPrep Nursing',version:3,exportedAt:new Date().toISOString(),saved:JSON.parse(localStorage.getItem('railprep_offline_v2')||'{}'),extra:{...extra}};let blob=new Blob([JSON.stringify(base,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='railprep-complete-backup-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);notice('Full study backup exported (API key excluded)')};$('importFull').onchange=e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let d=JSON.parse(r.result);if(d.saved)localStorage.setItem('railprep_offline_v2',JSON.stringify(d.saved));if(d.extra){extra={...extra,...d.extra};delete extra.apiKey;delete extra.model;}save();notice('Backup imported. Refresh to reload progress.')}catch(_){notice('Invalid backup file')} };r.readAsText(f);e.target.value=''};
// intercept nav buttons after existing app.js binds
nav.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>{let v=b.dataset.view;if(v==='practice'||v==='mock')setupQuiz(v==='mock'?'mock':'practice');if(v==='spaced')renderSpaced();if(v==='settings')loadSettings()}));
updateHomeStats();loadSettings();}
window.addEventListener('DOMContentLoaded',attach);
})();
