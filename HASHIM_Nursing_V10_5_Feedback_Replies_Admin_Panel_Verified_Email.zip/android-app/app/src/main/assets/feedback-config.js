// Firebase Web SDK configuration for HASHIM Nursing.
// These values identify the Firebase project; never place service-account secrets here.
window.HASHIM_FIREBASE_CONFIG = {
  apiKey: "AIzaSyDBzvrPouQSMvnSiRdlSQWbF6seT3lskoA",
  authDomain: "hashim-nursing.firebaseapp.com",
  projectId: "hashim-nursing",
  storageBucket: "hashim-nursing.firebasestorage.app",
  messagingSenderId: "486179550541",
  appId: "1:486179550541:android:b6e5b9f431574650af3304"
};
