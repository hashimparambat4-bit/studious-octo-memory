/* HASHIM Nursing private feedback, student inbox and admin replies (Firebase compat SDK). */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const ADMIN_EMAIL='hashimp3385@gmail.com';
const cfg=window.HASHIM_FIREBASE_CONFIG;
let auth=null,db=null,studentUid=null,taps=0,tapTimer=null;
const status=(id,msg)=>{const el=$(id);if(el)el.textContent=msg};
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function stamp(v){try{return v&&v.toDate?v.toDate().toLocaleString():''}catch(_){return ''}}
function ensurePanel(){
 if($('hashimFeedbackTools'))return;
 const section=$('view-feedback');if(!section)return;
 const box=document.createElement('div');box.id='hashimFeedbackTools';box.className='panel quizbox';box.style.cssText='max-width:760px;margin:14px auto';
 box.innerHTML=`<div class="section-head"><div><h3>My Feedback & Replies</h3><p>Privately view replies to feedback sent from this app on this device.</p></div></div><button class="btn" id="myFeedbackRefresh">Check replies ↻</button><div id="myFeedbackList" class="hint" style="margin-top:12px">Your submissions and replies will appear here.</div>`;
 section.appendChild(box);$('myFeedbackRefresh').onclick=loadStudentFeedback;
}
function ensureAdmin(){
 if($('hashimAdminOverlay'))return;
 const overlay=document.createElement('div');overlay.id='hashimAdminOverlay';overlay.hidden=true;
 overlay.style.cssText='position:fixed;inset:0;z-index:99999;background:rgba(3,9,20,.96);overflow:auto;padding:18px';
 overlay.innerHTML=`<div class="panel quizbox" style="max-width:900px;margin:4vh auto"><div class="section-head"><div><h2>HASHIM Nursing Admin</h2><p>Private feedback management</p></div><button class="ghost" id="adminClose">✕ Close</button></div>
 <div id="adminLoginBox"><p class="hint">Administrator sign-in</p><div class="formrow"><div class="field"><label for="adminEmail">Admin email</label><input id="adminEmail" type="email" autocomplete="username" value="${ADMIN_EMAIL}" readonly></div><div class="field"><label for="adminPassword">Password</label><input id="adminPassword" type="password" autocomplete="current-password" placeholder="Firebase admin password"></div></div><button class="btn primary" id="adminLogin">Sign in</button><p id="adminLoginStatus" class="hint" role="status"></p></div>
 <div id="adminDashboard" hidden><div class="toolsrow"><strong id="adminCount">Feedback</strong><button class="btn" id="adminRefresh">Refresh ↻</button><button class="ghost" id="adminLogout">Sign out</button></div><div id="adminFeedbackList" style="margin-top:14px"></div></div></div>`;
 document.body.appendChild(overlay);
 $('adminClose').onclick=()=>overlay.hidden=true;
 $('adminLogin').onclick=adminLogin;$('adminRefresh').onclick=loadAdminFeedback;$('adminLogout').onclick=adminLogout;
}
async function getStudent(){
 if(!auth)throw Error('Firebase Authentication is not initialized.');
 if(auth.currentUser&&!auth.currentUser.isAnonymous){await auth.signOut()}
 if(!auth.currentUser){const cred=await auth.signInAnonymously();studentUid=cred.user.uid}else studentUid=auth.currentUser.uid;
 return studentUid;
}
async function loadStudentFeedback(){
 const out=$('myFeedbackList');if(!db||!auth){status('myFeedbackList','Feedback service is unavailable. Check your internet connection.');return}
 out.textContent='Loading your feedback…';
 try{const uid=await getStudent();const snap=await db.collection('feedback').where('studentUid','==',uid).get();
 if(snap.empty){out.textContent='No feedback submissions found on this device yet.';return}
 const docs=snap.docs.sort((a,b)=>{const x=a.data().createdAt?.toMillis?.()||0,y=b.data().createdAt?.toMillis?.()||0;return y-x});
 out.innerHTML=docs.map(d=>{const x=d.data();return `<article class="panel" style="padding:13px;margin:10px 0"><div class="study-meta"><strong>${esc(x.type||'Feedback')}</strong><span class="pill">${x.adminReply?'Replied':'Awaiting reply'}</span></div><p>${esc(x.message)}</p><small class="hint">${esc(stamp(x.createdAt))}</small>${x.adminReply?`<div class="feedback good"><strong>Reply from HASHIM Nursing</strong><p>${esc(x.adminReply)}</p><small>${esc(stamp(x.repliedAt))}</small></div>`:'<p class="hint">The admin has not replied yet.</p>'}</article>`}).join('');
 }catch(e){console.error(e);out.textContent='Could not load feedback. Please try again when online.'}
}
async function adminLogin(){
 const pass=$('adminPassword').value;status('adminLoginStatus','Signing in…');
 if(!pass){status('adminLoginStatus','Enter your admin password.');return}
 try{
  const cred=await auth.signInWithEmailAndPassword(ADMIN_EMAIL,pass);
  if(!cred.user.emailVerified){await cred.user.sendEmailVerification();await auth.signOut();throw Error('A verification email was sent to '+ADMIN_EMAIL+'. Open that email, verify your address, then return here and sign in again.');}
  $('adminLoginBox').hidden=true;$('adminDashboard').hidden=false;status('adminLoginStatus','');await loadAdminFeedback();
 }catch(e){console.error(e);status('adminLoginStatus',e.message||'Sign-in failed. Check Firebase Authentication setup and password.')}
}
async function adminLogout(){try{await auth.signOut();}catch(_){}$('adminDashboard').hidden=true;$('adminLoginBox').hidden=false;$('adminPassword').value='';$('hashimAdminOverlay').hidden=true;}
async function loadAdminFeedback(){
 const out=$('adminFeedbackList');out.textContent='Loading feedback…';
 try{const user=auth.currentUser;if(!user||user.email!==ADMIN_EMAIL||!user.emailVerified)throw Error('Admin permission missing. Sign in with the verified admin email.');const snap=await db.collection('feedback').get();
 const docs=snap.docs.sort((a,b)=>(b.data().createdAt?.toMillis?.()||0)-(a.data().createdAt?.toMillis?.()||0));$('adminCount').textContent=`${docs.length} feedback message(s)`;
 if(!docs.length){out.textContent='No feedback received yet.';return}
 out.innerHTML=docs.map(d=>{const x=d.data();return `<article class="panel" style="padding:15px;margin:12px 0"><div class="study-meta"><strong>${esc(x.type||'Feedback')} ${x.rating?`· ${'★'.repeat(x.rating)}`:''}</strong><span class="pill">${x.adminReply?'Replied':'Pending'}</span></div><p>${esc(x.message)}</p><p class="hint">Name: ${esc(x.name||'Not provided')} · Question: ${esc(x.questionId||'—')}<br>App: ${esc(x.appVersion||'—')} · ${esc(stamp(x.createdAt))}</p><label for="reply-${d.id}">Reply to student</label><textarea id="reply-${d.id}" rows="3" maxlength="2000" class="tutor-input" placeholder="Write your reply…">${esc(x.adminReply||'')}</textarea><div class="toolsrow" style="margin-top:9px"><button class="btn primary" data-reply="${d.id}">Send reply</button><span class="hint" id="reply-status-${d.id}"></span></div></article>`}).join('');
 out.querySelectorAll('[data-reply]').forEach(b=>b.onclick=()=>sendReply(b.dataset.reply));
 }catch(e){console.error(e);out.textContent=e.message||'Could not load feedback.'}
}
async function sendReply(id){const field=$('reply-'+id),msg=field?.value.trim();if(!msg){status('reply-status-'+id,'Write a reply first.');return}try{await db.collection('feedback').doc(id).update({adminReply:msg,repliedAt:firebase.firestore.FieldValue.serverTimestamp(),status:'replied'});status('reply-status-'+id,'Reply sent ✓');}catch(e){console.error(e);status('reply-status-'+id,'Could not send reply. Check admin permissions.') }}
function init(){
 ensurePanel();ensureAdmin();
 const badge=$('connection');if(badge){badge.style.cursor='pointer';badge.title='';badge.addEventListener('click',()=>{taps++;clearTimeout(tapTimer);tapTimer=setTimeout(()=>taps=0,1800);if(taps>=5){taps=0;$('hashimAdminOverlay').hidden=false;$('adminLoginBox').hidden=false;$('adminDashboard').hidden=true;$('adminPassword').value='';status('adminLoginStatus','');}})}
 const form=$('feedbackForm');if(form){const submit=$('feedbackSubmit'),s=$('feedbackStatus');form.addEventListener('submit',async e=>{e.preventDefault();const message=$('feedbackMessage').value.trim();if(message.length<3){s.textContent='Please enter a little more detail.';return}if(!db){s.textContent='Feedback service is not configured.';return}submit.disabled=true;s.textContent='Sending securely…';try{const uid=await getStudent();await db.collection('feedback').add({type:$('feedbackType').value,rating:$('feedbackRating').value?Number($('feedbackRating').value):null,name:$('feedbackName').value.trim()||null,questionId:$('feedbackQuestion').value.trim()||null,message,app:'HASHIM Nursing',appVersion:'10.5',createdAt:firebase.firestore.FieldValue.serverTimestamp(),visibility:'private',studentUid:uid,status:'pending',adminReply:null,repliedAt:null});form.reset();s.textContent='Thank you! Your feedback was sent privately. You can check replies below.';await loadStudentFeedback()}catch(err){console.error(err);s.textContent='Could not send right now. Please check your connection and try again.'}finally{submit.disabled=false}})}
}
try{if(!cfg||!cfg.apiKey||!cfg.projectId||!cfg.appId)throw Error('Missing Firebase config');if(!firebase.apps.length)firebase.initializeApp(cfg);auth=firebase.auth();db=firebase.firestore();auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL).catch(()=>{});auth.onAuthStateChanged(user=>{if(user?.isAnonymous)studentUid=user.uid});if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();}catch(e){console.error('HASHIM feedback initialization:',e);}
})();
