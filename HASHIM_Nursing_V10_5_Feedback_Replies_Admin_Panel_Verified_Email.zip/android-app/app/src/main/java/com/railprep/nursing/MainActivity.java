package com.railprep.nursing;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.webkit.WebResourceRequest;
import android.net.Uri;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
  private WebView webView;
  private WebViewAssetLoader assetLoader;
  private long lastBackPressed = 0;
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    // Keep system bars visible; the WebView must not draw underneath the camera cutout/status bar.
    getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
      getWindow().setDecorFitsSystemWindows(true);
    } else {
      getWindow().getDecorView().setSystemUiVisibility(0);
    }
    getWindow().setStatusBarColor(android.graphics.Color.rgb(11,16,32));
    getWindow().setNavigationBarColor(android.graphics.Color.rgb(11,16,32));
    if (android.os.Build.VERSION.SDK_INT >= 26) {
      android.app.NotificationManager nm = (android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);
      nm.createNotificationChannel(new android.app.NotificationChannel("flashcard_daily", "Daily flashcard reminder", android.app.NotificationManager.IMPORTANCE_DEFAULT));
    }
    if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
      requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 410);
    }
    FlashcardReminderReceiver.schedule(this);
    assetLoader = new WebViewAssetLoader.Builder()
      .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
      .build();
    webView = new WebView(this);
    webView.setBackgroundColor(android.graphics.Color.rgb(11,16,32));
    webView.getSettings().setJavaScriptEnabled(true);
    webView.addJavascriptInterface(new Object() { @JavascriptInterface public void backToHome() { runOnUiThread(() -> webView.evaluateJavascript("window.railprepHandleBack ? window.railprepHandleBack() : 'home'", null)); } }, "RailPrepNative");
    webView.getSettings().setDomStorageEnabled(true);
    webView.getSettings().setAllowFileAccess(false);
    webView.getSettings().setAllowContentAccess(true);
    webView.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    webView.setWebChromeClient(new WebChromeClient());
    webView.setWebViewClient(new WebViewClient() {
      @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        return assetLoader.shouldInterceptRequest(request.getUrl());
      }
    });
    setContentView(webView);
    webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
  }
  @Override public void onBackPressed() {
    if (webView != null) {
      webView.evaluateJavascript("(function(){return window.railprepHandleBack ? window.railprepHandleBack() : 'home';})()", value -> {
        // If already at home, require a second back press to exit.
        if (System.currentTimeMillis() - lastBackPressed < 2000) {
          finish();
        } else {
          lastBackPressed = System.currentTimeMillis();
          Toast.makeText(MainActivity.this, "Press Back again to exit", Toast.LENGTH_SHORT).show();
        }
      });
    } else { super.onBackPressed(); }
  }
}
