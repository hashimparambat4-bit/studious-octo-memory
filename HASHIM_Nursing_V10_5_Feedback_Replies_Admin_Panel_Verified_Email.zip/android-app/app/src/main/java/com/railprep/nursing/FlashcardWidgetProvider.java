package com.railprep.nursing;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/** Home-screen widget backed by the same RAILPREP_NOTES dataset as the app. */
public class FlashcardWidgetProvider extends AppWidgetProvider {
  static final String ACTION_NEXT = "com.railprep.nursing.WIDGET_NEXT";
  static class Card { String subject, text; int number; Card(String s, String t, int n){subject=s;text=t;number=n;} }
  private static volatile List<Card> cards;

  private static List<Card> loadCards(Context c) {
    if (cards != null && !cards.isEmpty()) return cards;
    synchronized (FlashcardWidgetProvider.class) {
      if (cards != null && !cards.isEmpty()) return cards;
      List<Card> loaded = new ArrayList<>();
      try (InputStream in = c.getAssets().open("flashcards.json"); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
        byte[] buf = new byte[8192]; int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        JSONArray arr = new JSONArray(out.toString("UTF-8"));
        for (int i=0;i<arr.length();i++) {
          JSONObject o = arr.optJSONObject(i); if (o == null) continue;
          String text = o.optString("text", "").trim(); if (text.isEmpty()) continue;
          loaded.add(new Card(o.optString("subject", "Nursing"), text, o.optInt("number", i+1)));
        }
      } catch (Exception ignored) { }
      if (loaded.isEmpty()) loaded.add(new Card("Nursing", "Open RAILPREP Nursing to review your notes.", 1));
      cards = loaded; return cards;
    }
  }

  static void update(Context c, AppWidgetManager manager, int id) {
    List<Card> deck = loadCards(c);
    android.content.SharedPreferences prefs = c.getSharedPreferences("flashcard_widget", 0);
    int index = Math.floorMod(prefs.getInt("index", 0), deck.size());
    boolean reveal = prefs.getBoolean("reveal", false);
    Card card = deck.get(index);
    String raw = card.text;
    String question;
    String answer;
    java.util.regex.Matcher answerMatch = java.util.regex.Pattern.compile("(?i)\\s*Answer\\s*:").matcher(raw);
    if (answerMatch.find()) {
      question = raw.substring(0, answerMatch.start()).trim();
      answer = raw.substring(answerMatch.end()).trim();
      if (answer.isEmpty()) answer = "Review the source note for the answer.";
    } else {
      question = "Recall this key fact: " + raw;
      answer = raw;
    }
    RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.flashcard_widget);
    v.setTextViewText(R.id.widget_question, "QUESTION · " + card.subject + " · " + (index+1) + "/" + deck.size() + "\n" + question);
    v.setTextViewText(R.id.widget_answer, reveal ? "ANSWER: " + answer : "Think of your answer, then tap Show answer.");
    v.setTextViewText(R.id.widget_reveal, reveal ? "Next question →" : "Show answer");
    Intent next = new Intent(c, FlashcardWidgetProvider.class).setAction(ACTION_NEXT);
    v.setOnClickPendingIntent(R.id.widget_reveal, PendingIntent.getBroadcast(c, 10, next, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
    Intent open = new Intent(c, MainActivity.class);
    v.setOnClickPendingIntent(R.id.widget_open, PendingIntent.getActivity(c, 11, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
    manager.updateAppWidget(id, v);
  }
  @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for (int id : ids) update(c,m,id); }
  @Override public void onReceive(Context c, Intent i) {
    super.onReceive(c,i);
    if (ACTION_NEXT.equals(i.getAction())) {
      List<Card> deck = loadCards(c);
      android.content.SharedPreferences s = c.getSharedPreferences("flashcard_widget",0);
      boolean reveal = s.getBoolean("reveal",false);
      if (reveal) s.edit().putInt("index",(s.getInt("index",0)+1)%deck.size()).putBoolean("reveal",false).apply();
      else s.edit().putBoolean("reveal",true).apply();
      AppWidgetManager m = AppWidgetManager.getInstance(c);
      for(int id:m.getAppWidgetIds(new ComponentName(c,FlashcardWidgetProvider.class))) update(c,m,id);
    }
  }
}
