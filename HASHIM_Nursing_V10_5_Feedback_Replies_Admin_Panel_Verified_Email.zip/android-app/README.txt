RAILPREP NURSING — ANDROID STUDIO PROJECT


BUILD APK IN ANDROID STUDIO
1. Open this android-app folder in Android Studio.
2. Use JDK 17 and allow Gradle/Android Gradle Plugin dependencies to download.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is usually at app/build/outputs/apk/debug/app-debug.apk.

BUILD FROM AN ANDROID PHONE
1. Upload the extracted package contents to a GitHub repository (keep .github/workflows/build-apk.yml at the repository root and android-app/ at the root).
2. Open GitHub Actions, choose “Build RailPrep Nursing APK”, and run the workflow.
3. When complete, download the workflow artifact named railprep-nursing-debug-apk.

The current download contains the project source and build workflow, not a precompiled APK. No cloud sync is included.

AI REMOVED: This build contains no AI tutor, Gemini integration, API-key settings, or AI network requests. Notes, practice, revision and local backup work without AI.

MCQ options update: answer choices are filtered by answer type and similar format. Questions without three compatible distractors are skipped instead of being padded with unrelated options. Because source notes are one-line facts, review the source entry for accuracy.


NEW QUICK FLASHCARDS WIDGET + DAILY REMINDER
- After installing and opening the app, allow notifications when Android asks. A daily reminder is scheduled for around 7:00 PM (Android may deliver inexact alarms later).
- Add the home-screen widget: long-press an empty area of your Android home screen > Widgets > RailPrep Nursing / Quick Flashcard > drag it onto the home screen.
- Tap “Show answer” to reveal the answer and tap again for the next card. Tap the widget body to open the app.
- The widget currently uses a small built-in nursing review set; it does not yet sync the app's full offline notes database into the widget.


Flashcard widget integration update (2026-10-29): The Android home-screen widget now loads its deck from app/src/main/assets/flashcards.json, exported from the same RAILPREP_NOTES data used by the in-app notes. It cycles through all non-empty notes (subject + note number on the front; note text on reveal). To see this update, rebuild/reinstall the APK and remove/re-add or refresh the home-screen widget. The widget uses local bundled data and works offline.
