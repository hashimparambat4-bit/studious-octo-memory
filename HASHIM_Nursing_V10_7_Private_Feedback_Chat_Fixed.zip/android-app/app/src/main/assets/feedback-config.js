// Firebase Web App configuration for HASHIM Nursing.
// Public client configuration only. Never place service-account credentials here.
window.HASHIM_FIREBASE_CONFIG = {
  apiKey: "AIzaSyD3693VN5deYBXNBx-dFf0brEwEYi6bUWg",
  authDomain: "hashim-nursing.firebaseapp.com",
  projectId: "hashim-nursing",
  storageBucket: "hashim-nursing.firebasestorage.app",
  messagingSenderId: "486179550541",
  appId: "1:486179550541:web:9a62a1d4387bdd8eaf3304"
};
