/* HASHIM Nursing private feedback inbox + two-way message threads (Firebase compat SDK). */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const ADMIN_EMAIL='hashimp3385@gmail.com';
const cfg=window.HASHIM_FIREBASE_CONFIG;
let auth=null,db=null,studentUid=null,taps=0,tapTimer=null;
const status=(id,msg)=>{const el=$(id);if(el)el.textContent=msg};
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function stamp(v){try{return v&&v.toDate?v.toDate().toLocaleString():''}catch(_){return ''}}
function ensurePanel(){
 if($('hashimFeedbackTools'))return;
 const section=$('view-feedback');if(!section)return;
 const box=document.createElement('div');box.id='hashimFeedbackTools';box.className='panel quizbox';box.style.cssText='max-width:760px;margin:14px auto';
 box.innerHTML=`<div class="section-head"><div><h3>My Feedback & Replies</h3><p>Private conversations between you and HASHIM Nursing support. Only you can see your feedback and replies.</p></div></div><button class="btn" id="myFeedbackRefresh">Refresh conversations ↻</button><div id="myFeedbackList" class="hint" style="margin-top:12px">Your submissions and private conversations will appear here.</div>`;
 section.appendChild(box);$('myFeedbackRefresh').onclick=loadStudentFeedback;
}
function ensureAdmin(){
 if($('hashimAdminOverlay'))return;
 const overlay=document.createElement('div');overlay.id='hashimAdminOverlay';overlay.hidden=true;
 overlay.style.cssText='position:fixed;inset:0;z-index:99999;background:rgba(3,9,20,.96);overflow:auto;padding:18px';
 overlay.innerHTML=`<div class="panel quizbox" style="max-width:900px;margin:4vh auto"><div class="section-head"><div><h2>HASHIM Nursing Admin</h2><p>Private feedback conversations</p></div><button class="ghost" id="adminClose">✕ Close</button></div>
 <div id="adminLoginBox"><p class="hint">Administrator sign-in</p><div class="formrow"><div class="field"><label for="adminEmail">Admin email</label><input id="adminEmail" type="email" autocomplete="username" value="${ADMIN_EMAIL}" readonly></div><div class="field"><label for="adminPassword">Password</label><input id="adminPassword" type="password" autocomplete="current-password" placeholder="Firebase admin password"></div></div><button class="btn primary" id="adminLogin">Sign in</button><p id="adminLoginStatus" class="hint" role="status"></p></div>
 <div id="adminDashboard" hidden><div class="toolsrow"><strong id="adminCount">Feedback</strong><button class="btn" id="adminRefresh">Refresh ↻</button><button class="ghost" id="adminLogout">Sign out</button></div><div id="adminFeedbackList" style="margin-top:14px"></div></div></div>`;
 document.body.appendChild(overlay);
 $('adminClose').onclick=()=>overlay.hidden=true;
 $('adminLogin').onclick=adminLogin;$('adminRefresh').onclick=loadAdminFeedback;$('adminLogout').onclick=adminLogout;
}
async function getStudent(){
 if(!auth)throw Error('Firebase Authentication is not initialized.');
 if(auth.currentUser&&!auth.currentUser.isAnonymous){await auth.signOut()}
 if(!auth.currentUser){const cred=await auth.signInAnonymously();studentUid=cred.user.uid}else studentUid=auth.currentUser.uid;
 return studentUid;
}
function messageHTML(m,owner){const mine=owner?m.senderRole==='admin':m.senderRole==='student';return `<div class="feedback ${mine?'good':''}" style="margin:8px 0"><strong>${mine?(owner?'You (Admin)':'You'):(owner?'Student':'HASHIM Nursing')}</strong><p style="white-space:pre-wrap">${esc(m.message)}</p><small>${esc(stamp(m.createdAt))}</small></div>`}
async function readThread(ref,legacy){
 const snap=await ref.collection('messages').get();
 const msgs=snap.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(a.createdAt?.toMillis?.()||0)-(b.createdAt?.toMillis?.()||0));
 // Display replies created by the previous v10.5 single-reply implementation.
 if(legacy?.adminReply&&!msgs.some(m=>m.message===legacy.adminReply&&m.senderRole==='admin'))msgs.unshift({senderRole:'admin',message:legacy.adminReply,createdAt:legacy.repliedAt});
 return msgs;
}
async function loadStudentFeedback(){
 const out=$('myFeedbackList');if(!db||!auth){status('myFeedbackList','Feedback service is unavailable. Check your internet connection.');return}
 out.textContent='Loading your feedback…';
 try{const uid=await getStudent();const snap=await db.collection('feedback').where('studentUid','==',uid).get();
 if(snap.empty){out.textContent='No feedback submissions found on this device yet.';return}
 const docs=snap.docs.sort((a,b)=>(b.data().createdAt?.toMillis?.()||0)-(a.data().createdAt?.toMillis?.()||0));
 const cards=await Promise.all(docs.map(async d=>{const x=d.data(),msgs=await readThread(d.ref,x);return `<article class="panel" style="padding:13px;margin:10px 0"><div class="study-meta"><strong>${esc(x.type||'Feedback')}</strong><span class="pill">${msgs.length?'Conversation':'Awaiting reply'}</span></div><div class="feedback" style="margin:9px 0"><strong>Your original feedback</strong><p style="white-space:pre-wrap">${esc(x.message)}</p><small>${esc(stamp(x.createdAt))}</small></div><div>${msgs.map(m=>messageHTML(m,false)).join('')}</div><label for="student-msg-${d.id}">Send a private follow-up</label><textarea id="student-msg-${d.id}" rows="2" maxlength="2000" class="tutor-input" placeholder="Write a follow-up message…"></textarea><div class="toolsrow" style="margin-top:8px"><button class="btn" data-student-send="${d.id}">Send message</button><span class="hint" id="student-status-${d.id}"></span></div></article>`}));
 out.innerHTML=cards.join('');out.querySelectorAll('[data-student-send]').forEach(b=>b.onclick=()=>sendStudentMessage(b.dataset.studentSend));
 }catch(e){console.error(e);out.textContent='Could not load feedback. Please try again when online.'}
}
async function sendStudentMessage(id){const field=$('student-msg-'+id),msg=field?.value.trim();if(!msg){status('student-status-'+id,'Write a message first.');return}try{const uid=await getStudent();await db.collection('feedback').doc(id).collection('messages').add({senderRole:'student',senderUid:uid,message:msg,createdAt:firebase.firestore.FieldValue.serverTimestamp()});field.value='';status('student-status-'+id,'Message sent ✓');await loadStudentFeedback()}catch(e){console.error(e);status('student-status-'+id,'Could not send. Please try again when online.') }}
async function adminLogin(){
 const pass=$('adminPassword').value;status('adminLoginStatus','Signing in…');
 if(!pass){status('adminLoginStatus','Enter your admin password.');return}
 try{
  const cred=await auth.signInWithEmailAndPassword(ADMIN_EMAIL,pass);
  if(!cred.user.emailVerified){await cred.user.sendEmailVerification();await auth.signOut();throw Error('A verification email was sent to '+ADMIN_EMAIL+'. Verify your address, then return and sign in again.');}
  $('adminLoginBox').hidden=true;$('adminDashboard').hidden=false;status('adminLoginStatus','');await loadAdminFeedback();
 }catch(e){console.error(e);status('adminLoginStatus',e.message||'Sign-in failed. Check Firebase Authentication setup and password.')}
}
async function adminLogout(){try{await auth.signOut();}catch(_){}$('adminDashboard').hidden=true;$('adminLoginBox').hidden=false;$('adminPassword').value='';$('hashimAdminOverlay').hidden=true;}
async function loadAdminFeedback(){
 const out=$('adminFeedbackList');out.textContent='Loading feedback…';
 try{const user=auth.currentUser;if(!user||user.email!==ADMIN_EMAIL||!user.emailVerified)throw Error('Admin permission missing. Sign in with the verified admin email.');const snap=await db.collection('feedback').get();
 const docs=snap.docs.sort((a,b)=>(b.data().createdAt?.toMillis?.()||0)-(a.data().createdAt?.toMillis?.()||0));$('adminCount').textContent=`${docs.length} feedback conversation(s)`;
 if(!docs.length){out.textContent='No feedback received yet.';return}
 const cards=await Promise.all(docs.map(async d=>{const x=d.data(),msgs=await readThread(d.ref,x);return `<article class="panel" style="padding:15px;margin:12px 0"><div class="study-meta"><strong>${esc(x.type||'Feedback')} ${x.rating?`· ${'★'.repeat(x.rating)}`:''}</strong><span class="pill">${msgs.length?'Conversation':'Awaiting reply'}</span></div><div class="feedback" style="margin:10px 0"><strong>Original feedback</strong><p style="white-space:pre-wrap">${esc(x.message)}</p><small>Name: ${esc(x.name||'Not provided')} · Question: ${esc(x.questionId||'—')}<br>App: ${esc(x.appVersion||'—')} · ${esc(stamp(x.createdAt))}</small></div><div>${msgs.map(m=>messageHTML(m,true)).join('')}</div><label for="admin-msg-${d.id}">Reply privately</label><textarea id="admin-msg-${d.id}" rows="3" maxlength="2000" class="tutor-input" placeholder="Write your message to this student…"></textarea><div class="toolsrow" style="margin-top:9px"><button class="btn primary" data-admin-send="${d.id}">Send reply</button><span class="hint" id="admin-status-${d.id}"></span></div></article>`}));
 out.innerHTML=cards.join('');out.querySelectorAll('[data-admin-send]').forEach(b=>b.onclick=()=>sendAdminMessage(b.dataset.adminSend));
 }catch(e){console.error(e);out.textContent=e.message||'Could not load feedback.'}
}
async function sendAdminMessage(id){const field=$('admin-msg-'+id),msg=field?.value.trim();if(!msg){status('admin-status-'+id,'Write a reply first.');return}try{const user=auth.currentUser;if(!user||user.email!==ADMIN_EMAIL||!user.emailVerified)throw Error('Admin permission missing.');await db.collection('feedback').doc(id).collection('messages').add({senderRole:'admin',senderUid:user.uid,message:msg,createdAt:firebase.firestore.FieldValue.serverTimestamp()});await db.collection('feedback').doc(id).update({status:'replied'});status('admin-status-'+id,'Reply sent ✓');await loadAdminFeedback()}catch(e){console.error(e);status('admin-status-'+id,e.message||'Could not send. Check Firestore rules.') }}
function init(){
 ensurePanel();ensureAdmin();
 const badge=$('connection');if(badge){badge.style.cursor='pointer';badge.title='Tap five times for administrator sign-in';badge.addEventListener('click',()=>{taps++;clearTimeout(tapTimer);tapTimer=setTimeout(()=>taps=0,1800);if(taps>=5){taps=0;$('hashimAdminOverlay').hidden=false;$('adminLoginBox').hidden=false;$('adminDashboard').hidden=true;$('adminPassword').value='';status('adminLoginStatus','');}})}
 const form=$('feedbackForm');if(form){const submit=$('feedbackSubmit'),s=$('feedbackStatus');form.addEventListener('submit',async e=>{e.preventDefault();const message=$('feedbackMessage').value.trim();if(message.length<3){s.textContent='Please enter a little more detail.';return}if(!db){s.textContent='Feedback service is not configured.';return}submit.disabled=true;s.textContent='Sending securely…';try{const uid=await getStudent();await db.collection('feedback').add({type:$('feedbackType').value,rating:$('feedbackRating').value?Number($('feedbackRating').value):null,name:$('feedbackName').value.trim()||null,questionId:$('feedbackQuestion').value.trim()||null,message,app:'HASHIM Nursing',appVersion:'10.6',createdAt:firebase.firestore.FieldValue.serverTimestamp(),visibility:'private',studentUid:uid,status:'pending',adminReply:null,repliedAt:null});form.reset();s.textContent='Thank you! Your feedback was sent privately. You can follow the conversation in My Feedback & Replies.';await loadStudentFeedback()}catch(err){console.error(err);s.textContent='Could not send right now. Please check your connection and try again.'}finally{submit.disabled=false}})}
}
try{if(!cfg||!cfg.apiKey||!cfg.projectId||!cfg.appId)throw Error('Missing Firebase config');if(!firebase.apps.length)firebase.initializeApp(cfg);auth=firebase.auth();db=firebase.firestore();auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL).catch(()=>{});auth.onAuthStateChanged(user=>{if(user?.isAnonymous)studentUid=user.uid});if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();}catch(e){console.error('HASHIM feedback initialization:',e);}
})();
